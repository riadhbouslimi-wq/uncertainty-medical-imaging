Pretrained checkpoints for public datasets will be placed here.
