"""
Preprocessing pipeline for UG-GraphT5.
Includes resizing, normalization, augmentation, and label harmonization.
"""

def preprocess_image(image):
    # Resize to 512x512, normalize to [0,1]
    pass
