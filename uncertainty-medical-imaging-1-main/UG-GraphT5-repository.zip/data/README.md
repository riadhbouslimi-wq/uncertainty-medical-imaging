# Datasets

This project uses the following datasets:

- **MURA** (public)
- **IU-Xray** (public)
- **MIMIC-CXR** (public)
- **CT-RATE** (private, restricted)

Due to institutional and ethical constraints, CT-RATE cannot be released publicly.
Scripts and configuration templates are provided to apply the pipeline to any
comparable CT dataset subject to appropriate approval.
