# UG-GraphT5

Code for the paper:
**A Knowledge-Guided and Uncertainty-Calibrated Multimodal Framework
for Fracture Diagnosis and Radiology Report Generation**

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python training/train.py --config configs/config.yaml
```

## Reproducibility
This repository is provided for peer review purposes.
It will be made public upon acceptance.
