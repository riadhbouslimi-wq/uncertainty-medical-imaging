"""
Training script for UG-GraphT5.
"""
def train():
    pass

if __name__ == "__main__":
    train()
